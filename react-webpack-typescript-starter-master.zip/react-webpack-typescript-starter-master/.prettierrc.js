module.exports = {
    semi: true,
    trailingComma: "all",
};
